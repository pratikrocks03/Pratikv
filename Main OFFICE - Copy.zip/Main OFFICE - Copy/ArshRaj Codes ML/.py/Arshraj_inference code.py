#!/usr/bin/env python
# coding: utf-8

# In[1]:


#%%
try:
    import os
    import sys
    import warnings
    warnings.filterwarnings("ignore")
    print(f'Default working directory {os.getcwd()}')
    #change the directory to working directory
    #path =r"C:\Work_Anaconda\TripAdvisor\All_script_voting"
    path =r"C:\Users\arshraj.randhawa\Desktop\work2022\reikit model building"
    os.chdir(path)
    print(f'Current working directory {os.getcwd()}')
    #check the files in directory
    # print(f'Files in the current working directory are:\n{os.listdir()}')
except Exception as e:
    print(f'Error while setting up working directory : {sys.exc_info()[0]} , {e}')


# In[2]:



print('Importing Libraries & functions')
try :
    import warnings
    warnings.filterwarnings("ignore")
    import spacy
    #if spacy is not installed >>
    # pip install -U spacy
    # python -m spacy download en_core_web_lg
    import pandas as pd
    import joblib
    # pip install joblib
    import numpy as np
    import glob
    from sklearn.metrics import accuracy_score
    from support_file2 import *
    from sklearn.preprocessing import LabelEncoder
    from nltk.tokenize import sent_tokenize
    from sklearn.model_selection import train_test_split
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn import metrics
    from sklearn.metrics import confusion_matrix
    from sklearn.feature_selection import SelectFromModel
    from sklearn.ensemble import ExtraTreesClassifier, GradientBoostingClassifier
    from sklearn.linear_model import SGDClassifier
    from sklearn.naive_bayes import ComplementNB
    from keras.utils import to_categorical
    from keras.models import Sequential
    from keras.layers import Dense, Dropout
    from keras.callbacks import EarlyStopping
    print('Librabries and functions imported successfull')
except Exception as e:
    print(f'Error while importing librabries {sys.exc_info()[0]} , {e}')


# In[3]:


print('Importing new training data from Database')
try:
    #read data from the source
    # df = pd.read_sql_query()
    df = pd.read_excel('training_data_airwick.xlsx')

#         df = pd.read_pickle('ta_snippet_10032021.pkl')
    #only the 4 columns are necessary
    df = df[['ReviewID','Month', 'Title', 'Review', 'FullText','Rating','Title_Review','Level1','Level2','Level3']]
    head, shape, dtyp, colms, nul = dfinfo(df)
    #sort
    df.columns = [col.lower() for col in colms]
    df.sort_values(['reviewid', 'title'], inplace=True)
    df.dropna(subset=['review'],inplace=True)
    df.reset_index(drop=True, inplace=True)

    #lowering all text columns
    for col in ['title','month','review', 'fulltext', 'title_review']:
        df[col] = df[col].str.lower()
        df[col] = df[col].str.strip()
    del col
    df=df[df.month=="august"]
    df.reset_index(drop=True,inplace=True)
except Exception as e:
    print(f"Error while fetching the data data : {sys.exc_info()[0]} : {e}")
# df = df[['userreviewid', 'reviewtext']].drop_duplicates('userreviewid')


# In[4]:


df


# In[5]:



# =========================Pre processing======================================

print('Preproceing starts...')
try:
    df['review'] = df['review'].apply(cleantext)
    df = preprocess(df, 'review')
    df['cc1'] = df['cc1'].replace('', np.nan)
    head, shape, dtyp, colms, nul = dfinfo(df)
    nullreco = df[df['cc1'].isna()]
    #drop nul values
    dupli = df[df.duplicated(subset = ['reviewid', 'cc1'], keep=False)]
    df = df.drop_duplicates(subset=['reviewid', 'cc1']).reset_index(drop=True)
    df.reset_index(drop=True, inplace=True)
    #preparing dictionary d
    head, shape, dtyp, colms, nul = dfinfo(df)
    print("dropping null rows")
    df.dropna(subset=['cc1'],inplace=True)
    colms.remove('cc')
    d = uniq(df[colms])
    colms = list(df.columns)
    df['word'] = df['cc1'].str.split().str.len()
    df['len'] = df['cc1'].apply(len)
#     df = df[['reviewid', 'snippet', 'theme', 'sentiment', 'cc', 'cc1', '#word', 'len']]
    print('\nPreproceing of new Done')
except Exception as e:
    print(f'Error in preprocessing : {sys.exc_info()[0]} , {e}')


# In[6]:


df.info()


# In[7]:



# =============================================================================
try:
    print('Loading ML models')
    x = df['cc1']
    tf = joblib.load('tf')
    x_tf  = tf.transform(x)
    
    selector = joblib.load('selector')
    x_tf = selector.transform(x_tf)

    
except Exception as e:
    print(f"Error while prediction from ML models' : {sys.exc_info()[0]} : {e}")


# In[8]:


try:
    print('Running individual model with probability')
    # ======================================    
    m_sgd = joblib.load('m_sgd')
    m_gbt = joblib.load('m_gbt')
    m_cnb = joblib.load('m_cnb')
    le = joblib.load('le')
    # ======================================
    
    # ======================================
    print('Running the prediction on data')    
    # psgd = m_sgd.predict(x_tf)   
    # pgbt = m_gbt.predict(x_tf)
    # pcnb = m_cnb.predict(x_tf)
    # ======================================

    # ======================================
    pred_sgd = m_sgd.predict_proba(x_tf)
    pred = pd.DataFrame(data=pred_sgd, columns=le.classes_)
    pred['max'] = np.max(pred, axis=1)
    pred['them'] = pred.idxmax(axis=1)
    df['maxsgd'] = pred['max'].tolist()
    df['psgd'] = pred['them'].tolist()
    # ======================================    

    # ======================================
    pred_gbt = m_gbt.predict_proba(x_tf)
    pred = pd.DataFrame(data=pred, columns=le.classes_)
    pred['max'] = np.max(pred, axis=1)
    pred['them'] = pred.idxmax(axis=1)
    df['maxgbt'] = pred['max'].tolist()
    df['pgbt'] = pred['them'].tolist()
    # ======================================
    
    # ======================================
    pred_nb = m_cnb.predict_proba(x_tf)
    pred = pd.DataFrame(data=pred_nb, columns=le.classes_)
    pred['max'] = np.max(pred, axis=1)
    pred['them'] = pred.idxmax(axis=1)
    df['maxcnb'] = pred['max'].tolist()
    df['pcnb'] = pred['them'].tolist()
#     ======================================
    
    # psgd = le.inverse_transform(psgd)
    # pgbt = le.inverse_transform(pgbt)
    # pcnb = le.inverse_transform(pcnb)
    
    # df1['psgd'] = psgd.tolist()
    # df1['pgbt'] = pgbt.tolist()
    # df1['pcnb'] = pcnb.tolist()
    
    print('Successfully predicted results of 3 models')
except Exception as e:
    print(f"Error while prediction from ML models' : {sys.exc_info()[0]} : {e}")


# In[9]:


df


# In[10]:


df.to_csv('Final_output.csv', index=False)
print("results dumped to csv")


# In[ ]:




